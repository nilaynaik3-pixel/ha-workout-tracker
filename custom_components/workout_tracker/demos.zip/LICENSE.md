Exercise pictures and instructions: free-exercise-db
https://github.com/yuhonas/free-exercise-db
Released into the public domain under The Unlicense.
